<?php
public function user login form(){
	$sqlQuery = "
		SELECT * 
		FROM ".$this->membersTable." 
		WHERE email='".$_POST['userEmail']."' AND password='".md5($_POST['userPassword'])."'";			
	return  $this->getData($sqlQuery);
}

public function resetPassword(){
	$sqlQuery = "
		SELECT email 
		FROM ".$this->membersTable." 
		WHERE email='".$_POST['userEmail']."' OR username='".$_POST['userName']."'";			
	$result = mysqli_query($this->dbConnect, $sqlQuery);
	$numRows = mysqli_num_rows($result);
	if($numRows) {
		while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {				
			$link="Reset Password";				
			$to = $row['email'];
			$subject = "Reset your password on examplesite.com";
			$msg = "Hi there, click on this ".$link." to reset your password.";
			$msg = wordwrap($msg,70);
			$headers = "From: info@webdamn.com";
			mail($to, $subject, $msg, $headers);
			return 1;
		}
	} else {
		return 0;
	}
}
public function savePassword(){
	$sqlQuery = "
		SELECT email, authtoken 
		FROM ".$this->membersTable." 
		WHERE authtoken='".$_POST['authtoken']."'";			
	$result = mysqli_query($this->dbConnect, $sqlQuery);
	$numRows = mysqli_num_rows($result);
	if($numRows) {
		while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
			$sqlQuery = "
				UPDATE ".$this->membersTable." 
				SET password='".md5($_POST['newPassword'])."'
				WHERE email='".$row['email']."' AND authtoken='".$row['authtoken']."'";	
			mysqli_query($this->dbConnect, $sqlQuery);	
		}
		return 1;
	} else {
		return 0;
	}	
}

?>