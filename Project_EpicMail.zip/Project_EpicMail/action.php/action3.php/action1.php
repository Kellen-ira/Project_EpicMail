$('#loginForm').on('submit', function(e){
	$.ajax({
		type: 'POST',			
		url : "action.php",						
		data: $(this).serialize(),
		dataType: "json",
		success: function (response) {
			if(response.success == 1) {	
				location.href = "index.php";
			} else {
				$('#errorMessge').text(response.message);
				$('#errorMessge').removeClass('hidden');
			}				
		}
	});
	return false;
});