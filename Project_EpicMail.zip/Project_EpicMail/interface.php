<!DOCTYPE html>
<html>
<head>
	<title> WEBDEV CREATIONS</title>
<link rel="stylesheet" type="text/css" href="css1/style1.css">	
</head>
<body background="U.jpg">
<header>
	<div class="main">
     <div class="logo">
     <img src="images.jpg">	
     </div>
     </div>

	<ul>
	<li class="active"><a href="interface.php">home</a></li>	
<li><a href="index.html">sign-in</a></li>
<li><a href="resetpassword2.php">resetpassword</a></li>
<li><a href="Form.php">user1</a></li>
	</ul>	
	</div>
<div class="title">
<h1>WEBDEV CREATIONS</h1>
</div>
<div class="button">
<a href="#" class="btn">WATCH VIDEO</a>	
<a href="#" class="btn">LEARN MORE</a>
</div>
</header>
</body>
</html>