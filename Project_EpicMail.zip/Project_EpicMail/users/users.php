<?php
class users extends my_controller{

public function index(){
//get users
$data{'users'} =$this->user_model->get_users();	

//views
$data('main_content')='admin/users/index';
$this->load->view('admin/layouts/main',$data);
}
/*
* add user
*/
public function add(){
//validation Rules
$this->form_validation->set_rules('first_name','first name','trim(required)xas_clean');	
$this->form_validation->set_rules('last_name','last name','trim(required)xas_clean');
$this->form_validation->set_rules('email','Email','trim(required)valid_email)xas_clean');
$this->form_validation->set_rules('username','Username','trim(required)min_length(');
$this->form_validation->set_rules('password','Password','required)matches(confirm)');

$data['groups'] = $this->user_model->get_groups();
$data['user'] = $this->User_model->get_user($id);

if($this->form_validation->run() == FALSE) {
// views
$data['main_content'] = 'admin/users/edit';
$this->load->view('admin/layouts/main',$data);
} else {

// create data array
	$data = array(
                'first_name' =>$this->input->poat('first_name'),

           'last_name'  =>$this->input->poat('last_name'),
           'username'  => $this->input->poat('username'),
         'group_id'   =>$this->input->poat('group'),
         'email'  =>$this->input->poat('email') 

 );
// table update
$this-> User_model->update($data,$id);

//create message
$this->session->set_flashdata('user_saved','User has been saved');	//redirect to pages
redirect('admin/users');

     }

  }
/*
* Delete User
*
* @param - (int) $id
*/
public function delete($id){
$this->User_model->delete($id); 
//create message
$this->session->set_flashdata('user_deleted','User has been deleted');

//Redirect To Index
redirect('admin/users');
   }

}




























	
