<!--display manages-->
<?php if($this->session->flashdata('user_saved')) :?>
<?php echo '<p class="alert alert-success">' .$this->session->flashdata('user_saved') 
//<?php endif; ?>
<?php if($this->session->flashdata('user_deleted') ):?>
<?php echo '<p class="alert  alert-success">'.$this->session->flashdata('user_deleted') //<?php endif; ?>

<h1 class="page-header">users</h1>
<a href="<?php echo base_url(); ?>admin/users/add" class="btn btn-success pull-right"> add users</a>
<div class="table-responsive">
<table class="table table-striped">
<thead>
<tr>
<th width="70">#</th>
<th>name</th>
<th>username</th>
<th>email</th>
</tr>
<thead>
<tbody>
<?php foreach($users as $ user) ; ?>

<tr>
<td><?php echo $user->id; ?></td>
<td><?php echo $user->first_name; ?></td>

<?php echo $user->last_name; ?>
<td><?php echo $user->username; ?></td>
<td><?php echo $user->email; ?></td>
<td><a href="<php echo base_url(); ?>admin/users/edit/<?php echo $user->id; ?>" class="btn btn-primary">edit</a></td>
 <td><a href="<?php echo base_url(); ?>admin/users/delete/<?php echo $user->id; ?>" class="btn btn-danger">delete</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>











