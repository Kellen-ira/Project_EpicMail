<!DOCTYPE html>
<html>
<head>
	<title>Chat Box UI Design</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="container">
<div class="msg-header">
<div class="msg-header-img"
><img src="">
</div>	
</div>	
</div>
</body>
</html>