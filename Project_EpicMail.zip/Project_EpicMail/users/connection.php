<?php
$db="project_epicmaildb";
$con=mysqli_connect('localhost','root','','project_epicmaildb') or die('fail to connect to server').mysqli_error();

$query=mysqli_query($con,"INSERT INTO user1(id,firstname,lastname,username,password,confirmpassword,usergroup) VALUES ('$_POST[id]','$_POST[firstname]','$_POST[lastname]','$_POST[username]','$_POST[password]','$_POST[confirmpassword]','$_POST[usergroup]')"); 

if(! $con)

 {

echo "data does not inserted";

}
   else 
   	    {    

        echo " data inserted successfuly";

   	    }

?>






