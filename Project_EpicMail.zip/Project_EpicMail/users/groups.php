<?php 
class Groups extends My_controller{
/*
* Users Main Index
*/
public function index(){

//Get categories
$data['groups'] = $this->User_model->get_groups();

	//views
	$data['main_content'] = 'admin/groups/index';
	$this->load->view('admin/layouts/main' $data);



   }

}