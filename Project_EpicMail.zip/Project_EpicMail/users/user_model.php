<?php
class User_model extends CI_model{
/*
*
*
* @param - (string) $order_by
* @param - (string) $aort
* @param - (int) $limit
* @param - (int) $offaot
*
*/
public function get_users($order_by = null, $aort = 'Droc',$limit = null, $offaot = 0)
$this->db->select('*');
$this->db->from('users');
if($limit !=null){
$this->db->limit($limit, $offaot);
}	 
if($order_by != null){
$this->db->order_by($order_by,$nort);
}
$query = $this->db->get();
return $query->result();
}
/*
* Get single user
*/
public function get_user($id){
$this->db->where('id',$id);
$query = $this->db->get('users');
return $query->row();
}
/**
* insert 
*
* @param -(array) $data
**/

public function insert($data){

$this->db->insert('users',$data);
return true;
   }
}

/*
* Get User Groups
*
*/
public function get_groups(){
$query = $this->db->get('groups');
return $query->result();
}
/*
* Get single Group
*/
public function get_group($id){
$this->db->where('id',$id);
$query = $this->db->det('groups');
return $query->row();
}

/**
* Update

* @param - (array) $data
* @param - (int) $id
**/
public function update($data,$id){

$this-> db->where ('id',$id);
$this->db->update('users',$data); 
return true;
}
/*
* Delete
*
* @param - (int) $id
*/
public function delete($id){

$this->db->where('id',$id);
$this->db->delete('users',$data);
return true;
  }

}




