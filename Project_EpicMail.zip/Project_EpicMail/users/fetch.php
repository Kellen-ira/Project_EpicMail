<center>
<table border="5">
<tr>
<th>id</th>
<th>firstname</th>
<th>lastname</th>
<th>username</th>
<th>password</th>
<th>confirmpassword</th>
<th>usergroup</th>
</tr>
<?php
$conne = mysqli_connect('localhost','root','','project_epicmaildb') or die('connect error').mysqli_error();
$query = mysqli_query($conne,"SELECT * FROM user1");
while ($row=mysqli_fetch_array($query)) {
	$id =$row ['id'];
    $firstname=$row ['firstname'];
    $lastname =$row ['lastname'];
    $username =$row ['username'];
    $password =$row ['password'];
    $confirmpassword =$row ['confirmpassword'];
    $usergroup =$row ['usergroup'];
    ?>

    <tr>
   <td><?=$id;?></td>
   <td><?=$firstname;?></td>
   <td><?=$lastname;?></td>
   <td><?=$username;?></td>
   <td><?=$password;?></td>
   <td><?=$confirmpassword;?></td>
   <td><?=$usergroup;?></td>
   <td><button><a href="Delete.php" ?id=<?=$id;?>></a>Delete</button></td>
   </tr>
</center>
<?php
}
?>
</table>